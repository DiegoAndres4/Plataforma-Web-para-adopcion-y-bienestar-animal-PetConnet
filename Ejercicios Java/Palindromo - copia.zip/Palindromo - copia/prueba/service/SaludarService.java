package com.example.prueba.service;

import org.springframework.http.ResponseEntity;

public interface SaludarService {
    ResponseEntity<String> Saludar();
}
